<?php

define('DEBUG', true);

define('DB_DRIVE', 'mysql');
define('DB_HOSTNAME', '127.0.0.1');
define('DB_DATABASE', 'estoque');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'alura');