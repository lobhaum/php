<?php

class Conta
{
    public $cpfTitular;
    public $nomeTitular;
    public $saldo;
}
